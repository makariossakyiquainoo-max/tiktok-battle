import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const here = path.dirname(fileURLToPath(import.meta.url));
const clients = new Set();
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || true }));
app.use(express.json({ limit: '64kb' }));
app.use(express.static(here));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'two-team-battle', giftEvents: 'webhook-ready', tiktokAuth: 'not-configured' }));

// SSE stream consumed by the browser arena. Each connected arena receives gift events.
app.get('/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();
  res.write(`event: ready\ndata: ${JSON.stringify({ ok: true })}\n\n`);
  clients.add(res);
  const heartbeat = setInterval(() => res.write(': keepalive\n\n'), 20000);
  req.on('close', () => { clearInterval(heartbeat); clients.delete(res); });
});

function publishGift(payload) {
  const event = { type: 'gift', username: String(payload.username || payload.uniqueId || payload.nickname || 'Viewer'), giftName: String(payload.giftName || payload.gift || payload.name || ''), giftId: payload.giftId ?? null, timestamp: Date.now() };
  for (const client of clients) client.write(`event: gift\ndata: ${JSON.stringify(event)}\n\n`);
  return event;
}

// Configure your supported LIVE-event provider to POST normalized gift events here.
app.post('/webhook/gift', (req, res) => {
  const expected = process.env.WEBHOOK_SECRET;
  const supplied = req.get('x-webhook-secret');
  if (!expected || expected === 'change-this-to-a-long-random-secret' || supplied !== expected) return res.status(401).json({ error: 'Invalid or unconfigured webhook secret' });
  const body = req.body || {};
  const giftName = String(body.giftName || body.gift || body.name || '');
  if (!giftName.toLowerCase().includes('donut')) return res.status(202).json({ ok: true, ignored: 'Only Donut gifts join the game' });
  const event = publishGift(body);
  res.json({ ok: true, forwarded: event });
});

// Local testing only. Disabled unless ENABLE_DEV_GIFT=true.
app.post('/dev/gift', (req, res) => {
  if (process.env.ENABLE_DEV_GIFT !== 'true') return res.status(404).json({ error: 'Not found' });
  const event = publishGift({ username: req.body?.username || 'TestViewer', giftName: 'Donut' });
  res.json({ ok: true, forwarded: event });
});

// Deliberately does not pretend to provide TikTok OAuth. Connect a supported provider first.
app.get('/auth/tiktok/start', (_req, res) => res.status(501).json({ error: 'TikTok LIVE authorization is not configured. This starter server cannot log in to TikTok by itself. Connect an authorized LIVE event provider and forward Donut events to /webhook/gift.' }));

app.listen(PORT, () => console.log(`Battle backend listening on ${process.env.PUBLIC_URL || `http://localhost:${PORT}`}`));
