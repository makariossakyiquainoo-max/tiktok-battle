# Two-Team TikTok Battle — backend starter

This package connects the arena browser to a small Node.js event bridge. It supports a live Server-Sent Events stream and a secured webhook for normalized Donut gift events.

## Important TikTok limitation

This project does **not** implement TikTok login or independently read TikTok LIVE gifts. A standalone HTML file or this generic server cannot safely create that access. You must use a LIVE-event provider/integration that you are authorized to use, then configure it to POST gift events to this server. Do not give this app your TikTok password. The `/auth/tiktok/start` route intentionally returns HTTP 501 until a real supported authorization provider is configured.

## Run locally

1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and set a long random `WEBHOOK_SECRET`.
4. Add `ENABLE_DEV_GIFT=true` to `.env` for local testing only.
5. Run `npm start`.
6. Open `http://localhost:3000` and enter `http://localhost:3000` as the server URL.
7. Use the in-game simulated Donut button, or POST a test event to `/dev/gift`.

## Provider webhook format

Configure your authorized event provider to send an HTTP POST to:

`https://YOUR-HOST/webhook/gift`

Headers:

`Content-Type: application/json`

`x-webhook-secret: YOUR_WEBHOOK_SECRET`

Body example:

```json
{
  "username": "viewer_name",
  "giftName": "Donut",
  "giftId": "optional-provider-gift-id"
}
```

The server forwards the event to every connected arena browser at `/events`. The arena displays the Team A / Team B choice. The frontend enforces the six-player limit per team.

## Deploy

Deploy this folder to a Node.js host that supports long-lived HTTP responses (SSE). Set `PORT` (usually supplied by the host), `WEBHOOK_SECRET`, `FRONTEND_ORIGIN`, and optionally `PUBLIC_URL`. Use HTTPS in production. Keep `ENABLE_DEV_GIFT` unset/false in production. Add the deployed base URL to the arena's integration server URL field.

## Routes

- `GET /health` — server health and capability status.
- `GET /events` — live event stream for connected arenas.
- `POST /webhook/gift` — secured provider webhook; forwards Donut gifts only.
- `POST /dev/gift` — local-only test route, enabled only with `ENABLE_DEV_GIFT=true`.
- `GET /auth/tiktok/start` — intentionally returns 501 until a real supported auth provider is configured.
